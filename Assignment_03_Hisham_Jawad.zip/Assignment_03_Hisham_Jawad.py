def digit_count(n):
    # Base case: if the number is a single digit
    n = abs(n)
    if n < 10:
        return 1
    # Recursive case: strip one digit and count the rest
    return 1 + digit_count(n // 10)

def maximum_value(lst):
    # Base case: empty list, return 0
    if len(lst) == 0:
        return 0
    # Base case: single item in list, return that item
    elif len(lst) == 1:
        return lst[0]
    # Recursive case: compare first item with max of the rest
    max_of_rest = maximum_value(lst[1:])
    return lst[0] if lst[0] > max_of_rest else max_of_rest

def tag_count(html, tag):
    # Look for the opening and closing tags in the HTML
    tag_open = f"<{tag}>"
    tag_close = f"</{tag}>"
    # Base case: if no more tags are found
    if tag_open not in html and tag_close not in html:
        return 0
    # Recursive case: find the next occurrence and count it
    new_html = html[html.find(tag_close) + len(tag_close):]
    return 1 + tag_count(new_html, tag)

def start_program():
    # Hardcoded sample HTML string
    sample_html = """
    <html>
    <head>
    <title>My Website</title>
    </head>
    <body>
    <h1>Welcome to my website!</h1>
    <p>Here you'll find information about me and my hobbies</p>
    <h2>Hobbies</h2>
    <ul>
    <li>Playing guitar</li>
    <li>Reading books</li>
    <li>Traveling</li>
    <li>Writing cool h1 tags</li>
    </ul>
    </body>
    </html>
    """

    # Menu loop
    while True:
        print("1. Count Digits")
        print("2. Find Max")
        print("3. Count Tags")
        print("4. Exit")
        choice = int(input("Enter a choice: "))

        if choice == 1:
            num = int(input("Enter an integer: "))
            print("Number of digits:", digit_count(num))
        elif choice == 2:
            lst = list(map(int, input("Enter a list of integers (separated by space): ").split()))
            print("Maximum value:", maximum_value(lst))
        elif choice == 3:
            tag = input("Enter an HTML tag (without <>): ")
            print("Occurrences of the tag:", tag_count(sample_html, tag))
        elif choice == 4:
            break
        else:
            print("Invalid choice. Please try again.")

start_program()
